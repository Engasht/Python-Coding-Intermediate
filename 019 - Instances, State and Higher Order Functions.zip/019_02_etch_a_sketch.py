# PyCharm Editor
# Created on Sun Jul 07 15:35:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 019 - 01 - Etch a Sketch


from turtle import Turtle, Screen

fati = Turtle()
screen = Screen()


def move_forward():
    fati.forward(10)


def move_backward():
    fati.backward(10)


def turn_clockwise():
    fati.right(10)


def turn_counter_clockwise():
    fati.left(10)


def clean_screen():
    fati.clear()
    fati.penup()
    fati.home()
    fati.setheading(0)
    fati.pendown()


screen.listen()
screen.onkeypress(key="w", fun=move_forward)
screen.onkeypress(key="s", fun=move_backward)
screen.onkeypress(key="a", fun=turn_counter_clockwise)
screen.onkeypress(key="d", fun=turn_clockwise)
screen.onkey(key="c", fun=clean_screen)
screen.exitonclick()

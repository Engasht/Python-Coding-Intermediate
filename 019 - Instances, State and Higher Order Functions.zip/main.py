# PyCharm Editor
# Created on Sun Jul 07 07:53:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 019 - Instances, State and Higher Order Functions

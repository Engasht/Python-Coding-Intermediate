# PyCharm Editor
# Created on Sun Jul 07 07:53:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 019 - Listeners and Higher Order Functions


from turtle import Turtle, Screen


def move_forward():
    ali.forward(10)


ali = Turtle()
screen = Screen()
screen.listen()
# When using a function as an argument don't use parenthesis.
# Parenthesis make the function to be triggered there and then.
# We want onkey method to listen and as soon as space is pressed then triggers the function.
# In general:
# function_a(function_b)
# function_a is a Higher Order Function
screen.onkey(key="space", fun=move_forward)
screen.exitonclick()

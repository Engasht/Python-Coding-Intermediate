# PyCharm Editor
# Created on Sun Jul 08 18:08:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 019 - 03 Turtles Race

# We can have multiple instances of an object
# Each instance could have different states

from turtle import Turtle, Screen
import random


is_race_on = False
screen = Screen()
screen.setup(width=500, height=400)
user_bet = screen.textinput(title="Make your bet", prompt="Which turtle will win the race? Enter a color: ")
colors = ["red", "orange", "yellow", "green", "blue", "purple"]
turtles = []
separator = -2.5
for color in colors:
    contender = Turtle(shape="turtle")
    contender.penup()
    contender.color(color)
    contender.goto(x=-240, y=50 * separator)
    turtles.append(contender)
    separator += 1
if user_bet:
    is_race_on = True
while is_race_on:
    for turtle in turtles:
        rand_distance = random.randint(0, 10)
        turtle.forward(rand_distance)
        if turtle.xcor() > 220:
            is_race_on = False
            winning_color = turtle.pencolor()
            if winning_color == user_bet:
                print(f"You've won! The {winning_color} turtle is the winner!")
            else:
                print(f"You've lost! The {winning_color} turtle is the winner!")
screen.exitonclick()

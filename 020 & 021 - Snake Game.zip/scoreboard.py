from turtle import Turtle
ALIGNMENT = "center"
FONT = ("Arial", 12, "normal")
X_POS = 0
Y_POS = 280


class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.color("yellow")
        self.penup()
        self.goto(x=X_POS, y=Y_POS)
        self.hideturtle()
        self.score = 0
        self.refresh()

    def add_score(self):
        self.score += 1
        self.refresh()

    def refresh(self):
        self.clear()
        self.write(f"Score = {self.score}", False, align=ALIGNMENT, font=FONT)

    def game_over(self):
        self.goto(0, 0)
        self.write("Game Over!", False, align=ALIGNMENT, font=FONT)

# PyCharm Editor
# Created on Sun Jun 7 19:02:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 016 - 02 - Coffee Machine OOP

from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

menu = Menu()
machine = CoffeeMaker()
transaction = MoneyMachine()
while True:
    order = input(f"What would you like? {menu.get_items()}: ")
    if order == "off":
        break
    elif order == "report":
        machine.report()
        transaction.report()
    else:
        item = menu.find_drink(order)
        if item is not None and machine.is_resource_sufficient(item):
            if transaction.make_payment(item.cost):
                machine.make_coffee(item)

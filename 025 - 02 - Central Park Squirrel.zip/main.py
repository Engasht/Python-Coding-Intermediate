# PyCharm Editor
# Created on Sun Jul 31 16:33:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 025 - 02 - Central Park Squirrel

import pandas

data = pandas.read_csv("Squirrel_Data.csv")
fur_color = data["Primary Fur Color"].tolist()
color_counts = [0, 0, 0]
for color in fur_color:
    if color == "Gray":
        color_counts[0] += 1
    elif color == "Black":
        color_counts[1] += 1
    elif color == "Cinnamon":
        color_counts[2] += 1
color_counts_dict = {
    "Fur Color": ["Gray", "Black", "Cinnamon"],
    "Count": color_counts
}
data_frame = pandas.DataFrame(color_counts_dict)
data_frame.to_csv("Results.csv")
print(data_frame)

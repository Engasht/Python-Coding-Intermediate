# PyCharm Editor
# Created on Sun Jul 16 11:33:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 022 - Pong Game

from turtle import Screen
from paddle import Paddle
from scoreboard import Scoreboard
import math
from ball import Ball
import time

screen = Screen()
screen.setup(width=800, height=600)
screen.bgcolor("black")
screen.title("Pong Game")
screen.tracer(0)
screen.listen()

right_paddle = Paddle((350, 0), "blue")
left_paddle = Paddle((-350, 0), "red")
# Set the ball to head to upper right corner
heading_of_ball = math.degrees(math.atan(.75))
ball = Ball(heading_of_ball)
scoreboard = Scoreboard()

screen.onkeypress(right_paddle.move_up, "Up")
screen.onkeypress(right_paddle.move_down, "Down")
screen.onkeypress(left_paddle.move_up, "w")
screen.onkeypress(left_paddle.move_down, "s")

sleep_time = .05
game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(sleep_time)
    ball.move()
    ball.is_collided_with_walls(280, -280)
    # Check the ball if collided with paddles. We need second conditions not to bounce on the back of paddles.
    if 330 < ball.xcor() < (330 + ball.ball_speed):
        ball.is_collided_with_paddle(right_paddle)
        sleep_time *= .9
    if (-330 - ball.ball_speed) < ball.xcor() < -330:
        ball.is_collided_with_paddle(left_paddle)
        sleep_time *= .9
    # If the ball exits the screen
    if ball.xcor() > 400:
        scoreboard.l_point()
        ball.reset_position()
        sleep_time = .05
    if ball.xcor() < -400:
        scoreboard.r_point()
        ball.reset_position()
        sleep_time = .05


screen.exitonclick()

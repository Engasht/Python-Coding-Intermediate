from turtle import Turtle


class Paddle(Turtle):
    def __init__(self, cord_of_paddle, color):
        super().__init__()
        self.shape("square")
        self.color(color)
        self.penup()
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.goto(cord_of_paddle)

    def move_up(self):
        if self.ycor() < 250:
            self.goto(self.xcor(), self.ycor() + 20)

    def move_down(self):
        if self.ycor() > -240:
            self.goto(self.xcor(), self.ycor() - 20)

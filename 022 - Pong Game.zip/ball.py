from turtle import Turtle
PADDLE_HALF_LENGTH = 50


class Ball(Turtle):
    def __init__(self, initial_direction):
        super().__init__()
        self.ball_speed = 8
        self.shape("circle")
        self.penup()
        self.color("white")
        self.setheading(initial_direction)

    def move(self):
        self.forward(self.ball_speed)

    def is_collided_with_walls(self, top_ycor, bottom_ycor):
        if self.ycor() > top_ycor or self.ycor() < bottom_ycor:
            self.setheading(360 - self.heading())

    def is_collided_with_paddle(self, paddle):
        if paddle.ycor() - PADDLE_HALF_LENGTH < self.ycor() < paddle.ycor() + PADDLE_HALF_LENGTH:
            self.setheading(180 - self.heading())

    def reset_position(self):
        self.goto(0, 0)
        self.setheading(self.heading() + 180)

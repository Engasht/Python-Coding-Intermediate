# PyCharm Editor
# Created on Sun Jul 18 23:15:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 023 - Turtle Crossing Game

import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.title("Turtle Crossing Game")
screen.bgcolor("grey20")
screen.tracer(0)
screen.listen()

player = Player()
# It seems that turtle is 30 * 15
car_manager = CarManager(-260, 270, 300, -300)
scoreboard = Scoreboard()

screen.onkey(fun=player.move, key="space")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()
    car_manager.update()
    if car_manager.detect_collision(player):
        scoreboard.game_over()
        screen.update()
        game_is_on = False
    if player.reach_finish():
        player.level_up()
        car_manager.increase_speed()
        scoreboard.level_up()

screen.exitonclick()

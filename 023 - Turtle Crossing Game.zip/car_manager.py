from turtle import Turtle
import random
COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager:
    def __init__(self, bottom_ycor, top_ycor, right_xcor, left_xcor):
        super().__init__()
        self.cars = []
        self.speed_of_cars = STARTING_MOVE_DISTANCE
        self.top = top_ycor
        self.bottom = bottom_ycor
        self.right = right_xcor
        self.left = left_xcor
        self.initializing_start()

    def initializing_start(self):
        number_of_lanes = int((self.top - self.bottom) / 25)
        y_cord = self.bottom + 10
        for _ in range(number_of_lanes):
            for car in range(1):
                x_cord = self.new_pos("inside")
                self.add_car((x_cord, y_cord))
            for car in range(1):
                x_cord = self.new_pos("outside")
                self.add_car((x_cord, y_cord))
            y_cord += 25

    def new_pos(self, placing):
        range_of_x = (self.right - 20) - (self.left + 20)
        if placing == "inside":
            x_cord = (random.random() * range_of_x) - (self.right - 20)
        else:
            x_cord = (random.random() * range_of_x) + (self.right + 20)
        return x_cord

    def add_car(self, position):
        new_car = Turtle("square")
        new_car.penup()
        new_car.color(random.choice(COLORS))
        new_car.shapesize(stretch_wid=1, stretch_len=2)
        new_car.setheading(180)
        new_car.goto(position)
        self.cars.append(new_car)

    def move(self):
        for car in self.cars:
            car.forward(self.speed_of_cars)

    def repos_exited_cars(self):
        for car in self.cars:
            if car.xcor() < self.left - 20:
                new_x_cord = self.new_pos("outside")
                y_cord = car.ycor()
                car.goto(new_x_cord, y_cord)

    def increase_speed(self):
        self.speed_of_cars += MOVE_INCREMENT

    def update(self):
        self.move()
        self.repos_exited_cars()

    def detect_collision(self, player):
        for car in self.cars:
            if -25 < car.xcor() - player.xcor() < 25 and -20 < car.ycor() - player.ycor() < 30:
                print(f" car y: {car.ycor()} and car x: {car.xcor()}")
                return True
        return False

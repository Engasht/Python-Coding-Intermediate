# PyCharm Editor
# Created on Sun Jul 24 10:59:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 024 - 01 - Snake Game With High Score

# To read a text file use open() and then read()
# always remember to close the file with close() or
# use with open() as file:
# It automatically closes the file.
# to write in a file use write()
# mode should be defined: w for replacing all content or a for appending to the content
# To create a new file use open() with a name that does not exist and mode of w

from turtle import Screen
from snake import Snake
from food import Food
from scoreboard import Scoreboard
import time
from gamecontrol import GameControl


screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("My Snake Game")
screen.tracer(0)

controller = GameControl()

screen.listen()
screen.onkey(controller.stop, "x")
screen.onkey(controller.start, "s")

while not controller.start_game:
    screen.update()

snake = Snake()
food = Food()
scoreboard = Scoreboard()

screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(0.1)
    snake.move()

    #Detect collision with food.
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend()
        scoreboard.increase_score()

    #Detect collision with wall.
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        scoreboard.reset()
        snake.reset()

    #Detect collision with tail.
    for segment in snake.segments:
        if segment == snake.head:
            pass
        elif snake.head.distance(segment) < 10:
            scoreboard.reset()
            snake.reset()

    # Check stop game
    if controller.stop_game:
        game_is_on = False


screen.exitonclick()

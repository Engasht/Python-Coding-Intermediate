from turtle import Turtle


class GameControl(Turtle):
    def __init__(self):
        super().__init__()
        self.start_game = False
        self.stop_game = False
        self.penup()
        self.color("green")
        self.hideturtle()
        self.write("Press 's' to start", align="center", font=("Courier", 30, "bold"))
        self.goto(0, -250)
        self.write("To exit the game during playing, press 'x'", align="center", font=("Courier", 10, "normal"))

    def start(self):
        self.clear()
        self.start_game = True

    def stop(self):
        self.stop_game = True

# PyCharm Editor
# Created on Tue Aug 02 09:13:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 025 - 03 - US States Game

import turtle
import pandas
import os

FONT = ("Courier", 8, "bold")
IMAGE_WIDTH = 725
IMAGE_HEIGHT = 491
IMAGE = "blank_states_img.gif"
DATA_FILE = "50_states.csv"
GAME_RESULT = "game_result.csv"

# Creating the screen and set the background of US map
screen = turtle.Screen()
screen.setup(width=IMAGE_WIDTH, height=IMAGE_HEIGHT)
screen.title("U.S. States Game")
screen.addshape(IMAGE)
turtle.shape(IMAGE)

# A turtle which will write the name of States
writer = turtle.Turtle()
writer.penup()
writer.hideturtle()

# Loading the original data to 1. list the states name for a fresh game 2. locate the state when it is written
file = pandas.read_csv(DATA_FILE)

# Check if the previous game is saved and user wants it to be loaded
if os.path.isfile(GAME_RESULT):
    if screen.textinput(title="Choose Game", prompt="Do you want to continue the previous game? yes/no") == "yes":
        # Remaining states
        saved_file = pandas.read_csv(GAME_RESULT)
        states = saved_file.state.tolist()
    else:
        states = file.state.tolist()
else:
    states = file.state.tolist()

# To be shown in text box title
correct_answers = 50 - len(states)

# while loop condition
guessing = True

# If previous game is loaded, set the text box title to correct value and write the name of guessed states on map
if len(states) < 50:
    text_title = f"{correct_answers}/50 States Correct"
    for state in file.state.tolist():
        if state not in states:
            state_details = file[file.state == state]
            writer.goto(int(state_details.x), int(state_details.y))
            writer.write(arg=state, align="center", font=FONT)
else:
    text_title = "Guess the State"

while guessing:
    user_guess = screen.textinput(title=text_title, prompt="What's another state's name?")

    # If cancel is clicked then exit the loop
    if user_guess is None:
        guessing = False
    else:
        user_guess = user_guess.title()

    # Alternately, if user_guess in states
    if states.count(user_guess) == 1:
        state_details = file[file.state == user_guess]
        writer.goto(int(state_details.x), int(state_details.y))
        writer.write(arg=user_guess, align="center", font=FONT)
        states.remove(user_guess)
        correct_answers += 1

        text_title = f"{correct_answers}/50 States Correct"

        # All states are guessed
        if correct_answers == 50:
            guessing = False
            writer.goto(0, 0)
            writer.color("blue")
            writer.write(arg="You Won!", align="center", font=("Courier", 24, "bold"))
            states = file.state.tolist()

# save result
result_dict = {
    "state": states
}
pandas.DataFrame(result_dict).to_csv(GAME_RESULT)

screen.mainloop()

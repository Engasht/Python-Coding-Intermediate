# PyCharm Editor
# Created on Sat Jul 30 18:56:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 025 - 01 - Working with CSV Data and Pandas Library

with open("weather_data.csv", mode="r") as file:
    data = file.readlines()
    print(data)

# Alternatively

import csv

with open("weather_data.csv") as file:
    data = csv.reader(file)
    temperatures = []
    for row in data:
        temperatures.append(row[1])
    temperatures = temperatures[1:]
    for _ in range(len(temperatures)):
        temperatures[_] = int(temperatures[_])
    print(temperatures)

# Alternatively and the best way is using Pandas

import pandas

data = pandas.read_csv("weather_data.csv")
print(data)
print(data["temp"])

# There are two types of data of Pandas: DataFrame and Series
print(type(data))
print(type(data["temp"]))

data_dict = data.to_dict()
print(data_dict)

temp_data = data["temp"].tolist()
print(temp_data)

# Calculating the average temperature
average_temp = round(data["temp"].mean(), 1)
print(f"Average Temperature is: {average_temp}")

# Maximum temperature
print(f"Maximum temperature is: {data['temp'].max()}")

# Another way of calling Columns
print(data.condition)

# Get data in row
print(data[data.day == "Monday"])
print(data[data.condition == "Rain"])

# Get the row with maximum temperature
print(data[data.temp == data.temp.max()])

monday = data[data.day == "Monday"]
print(monday.condition)


def c_to_f_convert(celsius_temperature):
    return celsius_temperature * 1.8 + 32


print(c_to_f_convert(monday.temp))


# Create a DataFrame from scratch
data_dict = {
    "students": ["Sara", "Mamad", "Bahar"],
    "scores" : [45, 95, 55]
}

data_frame = pandas.DataFrame(data_dict)
print(data_frame)
data_frame.to_csv("students_scores.csv")

# PyCharm Editor
# Created on Sun Jun 19 09:35:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 017 - 01 - Constructor and Initializing and Methods

# Creating classes
# class NameOfClass:
# and following codes should be indented

# Imagine we are creating a class for a website like Instagram:

class EmptyUser:
    # an empty class can't be left empty because the code can't recognize it.
    # We should use pass keyword
    # It's the same for functions
    pass


def empty_function():
    pass


# Notice, class names should use PascalCase, all words are capitalized.
# It differs from camelCase which the first word is lower case.
# We use snake_case to name variables and other things, all words are lower case separated by underscore.
user = EmptyUser()

# To add attribute to an instance of an object:
# (An attribute is a variable that is attached to an object)
user.idn = "000"

print(user.idn)

# If there are so many attributes for an object, there is a chance of typo or other mistakes.
# By using Constructor we can add all of these attributes when creating an instance of an object.
# Constructor is a part of the blueprint of the object.
# The process is known as initializing an object. We can set variables and counters.
# to make the Constructor use below function:
# def __init__(self):
# This function is called everytime a new object is created with the class.
# Some attributes don't need to be passed in like followers.


class User:
    # Creating attributes
    def __init__(self, user_id, username):
        print("New user being created ...")
        self.id = user_id
        self.username = username
        self.followers = 0
        self.following = 0

    # Creating methods
    def follow(self, user):
        user.followers += 1
        self.following += 1


user_1 = User("001", "Mani")
print(user_1.username)
print(user_1.followers)
user_2 = User("002", "Shadi")

user_1.follow(user_2)

print(user_1.followers)
print(user_1.following)
print(user_2.followers)
print(user_2.following)


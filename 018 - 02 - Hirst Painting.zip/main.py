# PyCharm Editor
# Created on Tue Jul 05 15:55:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 02 - Hirst Painting

# Couldn't find on Anaconda, instead the code below worked:
# pip install colorgram
# Then File -> Settings -> Project
import colorgram
import turtle
import random

number_of_colors = 50
number_of_rows = 10
number_of_columns = 10
dot_size = 20
distance_between_dots = 50


def set_position(row_number, col_number):
    initial_x = -((number_of_columns - 1) / 2) * distance_between_dots
    initial_y = -((number_of_rows - 1) / 2) * distance_between_dots
    x = initial_x + col_number * distance_between_dots
    y = initial_y + row_number * distance_between_dots
    return [x, y]


colors_extracted = colorgram.extract("image.jpg", number_of_colors)
colors = []
for color in colors_extracted:
    rgb_color = color.rgb
    r = rgb_color[0]
    g = rgb_color[1]
    b = rgb_color[2]
    # To remove shades of white of the background
    if r + g + b <= 720:
        colors.append((r, g, b))
ali = turtle.Turtle()
ali.speed(5)
ali.penup()
ali.hideturtle()
screen = turtle.Screen()
screen.colormode(255)
for row in range(number_of_rows):
    for col in range(number_of_columns):
        position = set_position(row, col)
        ali.setposition(position[0], position[1])
        ali.dot(dot_size, random.choice(colors))
screen.exitonclick()

# PyCharm Editor
# Created on Tue Jul 03 14:55:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 02 - Importing

# Import a module
# Useful when you need it once or twice
import turtle
ali = turtle.Turtle()

# Using from ... import ...
# Useful when you need it more than three times
from turtle import Turtle
hasan = Turtle()
javad = Turtle()
ghasem = Turtle()

# Importing everything
# It is confusing and isn't suggested
from turtle import *

naghi = Turtle()

# Aliasing
import turtle as t
taghi = t.Turtle()

# Installing modules
# Just click on the red bulb and PyCharm install it
import heroes
print(heroes.gen())

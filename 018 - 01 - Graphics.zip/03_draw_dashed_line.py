# PyCharm Editor
# Created on Tue Jul 03 15:25:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 03 - Draw a Dashed Line

from turtle import Turtle, Screen
fati = Turtle()
screen = Screen()
fati.speed(1)
for _ in range(20):
    fati.forward(10)
    fati.penup()
    fati.forward(10)
    fati.pendown()
screen.exitonclick()

# PyCharm Editor
# Created on Tue Jul 04 12:23:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 05 - Random Walk

# Tuples are immutable
# my_tuple = (1, 3, 8)
# To convert a tuple to a list
# list(my_tuple)
import random
import turtle

colors_list = ["peach puff", "black", "dark slate gray", "royal blue", "sea green", "gold", "indian red", "snow4",
               "tomato", "medium orchid", "violet red"]
main_directions = [0, 90, 180, 270]
number_of_movements = 300
step_distance = 30
line_size = 3

jamshid = turtle.Turtle()
jamshid.pensize(line_size)
jamshid.speed(0)
screen = turtle.Screen()


def choose_color():
    # Choose a random color
    return random.random(), random.random(), random.random()
    # Choose from defined list of colors
    # return random.choice(colors_list)


def choose_heading():
    # Choose a random direction
    return random.random() * 360
    # Choose from the four main directions
    # return random.choice(four_directions)


for _ in range(number_of_movements):
    jamshid.color(choose_color())
    jamshid.setheading(choose_heading())
    jamshid.forward(step_distance)

screen.exitonclick()

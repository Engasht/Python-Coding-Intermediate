# PyCharm Editor
# Created on Tue Jul 02 18:14:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 01 - Graphics


# Consists of some separate exercises using turtle module

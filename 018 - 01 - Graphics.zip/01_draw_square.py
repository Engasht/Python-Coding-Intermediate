# PyCharm Editor
# Created on Tue Jul 02 18:14:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 01 - Draw Square

from turtle import Turtle, Screen

ali = Turtle()
screen = Screen()

ali.shape("turtle")
ali.color("SteelBlue1")

for _ in range(4):
    ali.forward(100)
    ali.right(90)

screen.exitonclick()

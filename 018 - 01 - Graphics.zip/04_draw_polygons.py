# PyCharm Editor
# Created on Tue Jul 03 15:55:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 04 - Draw Polygons

from turtle import Turtle, Screen
from random import random
ali = Turtle()
screen = Screen()
for poly in range(3, 11):
    rotation = 360 / poly
    ali.color(random(), random(), random())
    for side in range(poly):
        ali.forward(100)
        ali.right(rotation)
screen.exitonclick()

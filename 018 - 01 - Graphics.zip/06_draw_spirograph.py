# PyCharm Editor
# Created on Tue Jul 04 14:30:34 2022
# @author: Mani Mehrabi
# Part of a Python Bootcamp - Intermediate
# 018 - 06 - Draw Spirograph

import random
import turtle

line_size = 1
# None for circle
steps = None
radius = 100
decompression = 5

jamshid = turtle.Turtle()
jamshid.pensize(line_size)
jamshid.speed(0)
screen = turtle.Screen()

for _ in range(0, 360, decompression):
    jamshid.color(random.random(), random.random(), random.random())
    jamshid.setheading(_)
    jamshid.circle(radius, 360, steps)

screen.exitonclick()
